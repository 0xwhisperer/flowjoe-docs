# FlowJoe CLI

Control FlowJoe from a terminal while the desktop app is running. Requires Node.js 22.12 or newer.

Install the download published with the user manual:

```sh
npm install --global https://docs.flowjoe.app/downloads/flowjoe-cli-0.1.0.tgz
flowjoe-cli --help
```

In FlowJoe, turn on **Settings → Joe AI → Agent Bridge (MCP)**. Then run:

```sh
flowjoe-cli status
flowjoe-cli show
flowjoe-cli search "launch plan"
flowjoe-cli apply changes.json --preview
flowjoe-cli apply changes.json
```

Ordinary changes wait for approval in FlowJoe. Add `--autoapprove` to `apply`, `run` or `action` to skip
approval cards for that command, **including deletions**. Permissions, privacy protections and validation
still apply. The flag never changes saved settings or other clients' approvals.

Use `--json` for scripts. Use `run steps.json` for actions that need one shared connection, such as
uploading and placing a file or undoing an earlier action. Batches stop at the first failure; earlier
changes are not rolled back. Don't repeat a timed-out edit until you've checked FlowJoe.

Full setup, action examples, exit codes and troubleshooting:
https://docs.flowjoe.app/cli/getting-started

For development, run `node integrations/cli/bin/flowjoe-cli.cjs --help` from the FlowJoe repository.
This package is distributed as a manual download; it is not published to the npm registry.
